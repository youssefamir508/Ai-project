/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package ai_project;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;

/**
 *
 * @author giova
 */
public class FXMLDocumentController implements Initializable {
    @FXML
    private Label p1WallLabel;
    
    @FXML
    private Label p2WallLabel;
    
    @FXML
    private StackPane boardContainer;
    
    @FXML
    private Label statusLabel;
    
    @FXML
    private ComboBox<String> modeSelector;
    
    // --- Game State Variables ---
    private boolean isPlayer1Turn = true;
    private int p1Walls = 10;
    private int p2Walls = 10;
    
    // Player Starting Coordinates
    private int p1Row = 16, p1Col = 8; // Bottom center
    private int p2Row = 0, p2Col = 8;  // Top center
    
    // The visual pawns (Shapes)
    private javafx.scene.shape.Circle p1Pawn;
    private javafx.scene.shape.Circle p2Pawn;

    // This array will hold all 289 squares of our board so we can control them later!
    private StackPane[][] gridCells = new StackPane[17][17];
    
    @FXML
    private Label label;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
   @Override
    public void initialize(URL url, ResourceBundle rb) {
        // 1. Setup the Dropdown Menu options
        modeSelector.getItems().addAll("Human vs Human", "Human vs Computer");
        modeSelector.getSelectionModel().selectFirst(); // Select the first one by default

        // 2. Create the Grid system
       // 2. Create the Grid system
        GridPane board = new GridPane();
        board.setAlignment(Pos.CENTER);
        
        
        for (int i = 0; i < 17; i++) {
            javafx.scene.layout.ColumnConstraints colConst = new javafx.scene.layout.ColumnConstraints();
            javafx.scene.layout.RowConstraints rowConst = new javafx.scene.layout.RowConstraints();
            
            if (i % 2 == 0) {
                colConst.setPercentWidth(9.5);
                rowConst.setPercentHeight(9.5);
            } else {
                colConst.setPercentWidth(1.8);
                rowConst.setPercentHeight(1.8);
            }
            board.getColumnConstraints().add(colConst);
            board.getRowConstraints().add(rowConst);
        }

        // 3. The 17x17 Loop
        for (int row = 0; row < 17; row++) {
            for (int col = 0; col < 17; col++) {
                StackPane cell = new StackPane();
                cell.setUserData(new int[]{row, col}); 
                
               
                cell.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
                
                if (row % 2 == 0 && col % 2 == 0) {
                    cell.setStyle("-fx-background-color: #8B4513; -fx-border-color: #5D2906; -fx-border-width: 1;"); 
                } else if (row % 2 != 0 && col % 2 != 0) {
                    cell.setStyle("-fx-background-color: #3e2723;");
                } else {
                    cell.setStyle("-fx-background-color: #d7ccc8;"); 
                }

                cell.setOnMouseClicked(this::handleCellClick);
                gridCells[row][col] = cell;
                board.add(cell, col, row);
            }
        }
        // --- Create the Pawns ---
        p1Pawn = new javafx.scene.shape.Circle(20, javafx.scene.paint.Color.DODGERBLUE);
        p2Pawn = new javafx.scene.shape.Circle(20, javafx.scene.paint.Color.TOMATO);
        
        // Add them to their starting cells
        gridCells[p1Row][p1Col].getChildren().add(p1Pawn);
        gridCells[p2Row][p2Col].getChildren().add(p2Pawn);
        
        // Set initial turn text
        statusLabel.setText("Game Started! Player 1's Turn.");
        
        // 4. Inject the finished 17x17 board into the empty container you made in Scene Builder
        boardContainer.getChildren().add(board);
    }

    private void handleCellClick(MouseEvent event) {
        StackPane clickedCell = (StackPane) event.getSource();
        int[] coords = (int[]) clickedCell.getUserData();
        int row = coords[0];
        int col = coords[1];

        // 1. Did they click a Walkable Square?
        if (row % 2 == 0 && col % 2 == 0) {
            
            if (isPlayer1Turn) {
                // Remove Player 1 from old square
                gridCells[p1Row][p1Col].getChildren().remove(p1Pawn);
                // Update coordinates and add to new square
                p1Row = row; p1Col = col;
                clickedCell.getChildren().add(p1Pawn);
                statusLabel.setText("Player 1 moved. Player 2's Turn!");
            } else {
                // Remove Player 2 from old square
                gridCells[p2Row][p2Col].getChildren().remove(p2Pawn);
                // Update coordinates and add to new square
                p2Row = row; p2Col = col;
                clickedCell.getChildren().add(p2Pawn);
                statusLabel.setText("Player 2 moved. Player 1's Turn!");
            }
            
            // Switch Turns!
            isPlayer1Turn = !isPlayer1Turn; 

        // 2. Did they click a tiny Pillar?
        } else if (row % 2 != 0 && col % 2 != 0) {
            statusLabel.setText("Invalid: Cannot place anything on a pillar.");
            
        // 3. Did they click a Wall Slot?
        } else {
            // Check if it already has a wall
            if (clickedCell.getStyle().contains("#FFD700")) {
                statusLabel.setText("Invalid: A wall is already here!");
                return; // Stop the code here
            }

            // Place the wall visually
            clickedCell.setStyle("-fx-background-color: #FFD700;"); 
            
            // Deduct walls and switch turns
            if (isPlayer1Turn) {
                p1Walls--;
                // Note: You will need to link this to your Player 1 Wall Label text later!
                statusLabel.setText("Player 1 placed a wall. " + p1Walls + " left. Player 2's Turn!");
            } else {
                p2Walls--;
                // Note: You will need to link this to your Player 2 Wall Label text later!
                statusLabel.setText("Player 2 placed a wall. " + p2Walls + " left. Player 1's Turn!");
            }
            
            // Switch Turns!
            isPlayer1Turn = !isPlayer1Turn;
        }
    }
    
    @FXML
    public void handleReset(javafx.event.ActionEvent event) {
        
        p1Walls = 10;
        p2Walls = 10;
        isPlayer1Turn = true;
        
        p1WallLabel.setText("Player 1 Walls: 10");
        p2WallLabel.setText("Player 2 Walls: 10");
        statusLabel.setText("Game Reset! Player 1's Turn.");


        for (int row = 0; row < 17; row++) {
            for (int col = 0; col < 17; col++) {

                if ((row % 2 == 0 && col % 2 != 0) || (row % 2 != 0 && col % 2 == 0)) {
                    gridCells[row][col].setStyle("-fx-background-color: #15344F;");
                }
            }
        }

       
        gridCells[p1Row][p1Col].getChildren().remove(p1Pawn);
        gridCells[p2Row][p2Col].getChildren().remove(p2Pawn);

        
        p1Row = 16; p1Col = 8; // Bottom center
        p2Row = 0;  p2Col = 8; // Top center

       
        gridCells[p1Row][p1Col].getChildren().add(p1Pawn);
        gridCells[p2Row][p2Col].getChildren().add(p2Pawn);
    }
}
